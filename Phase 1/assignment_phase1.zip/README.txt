IERG 4210 Assignment Phase 1
Name: Cheng Wing Lam
SID: 1155125313

*****************************************************************************************************************

/image folder is used to store the product image

/Categories folder has 3 folders and 3 .html files inside
- /Cleaner
- /Drink
- /Food

- Cleaner.html
- Drink.html
- Food.html

Each Categories folder( /Cleaner , /Drink , /Food) have 3 products

*****************************************************************************************************************

There are only one .css file (style.css)

*****************************************************************************************************************

Please open Home.html to start the dummy page.